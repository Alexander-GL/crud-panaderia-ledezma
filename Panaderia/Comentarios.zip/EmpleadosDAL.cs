﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;        // Librerias

namespace Panaderia
{
    class EmpleadosDAL // Esta clase tendra el acceso en capas a la base de datos.
    {
        public static int Agregar(Empleado pEmpleado) // Esta clase sirve para agregar un empleado a la BD
        {
            int retorno = 0;
            MySqlCommand comando = new MySqlCommand(string.Format("Insert into  empleado (ID, Clave, Dirección, Telefono," +
                " Nombre, Apellido1, Apellido2, Puesto) values ('{0}','{1}','{2}','{3}','{4}','{5}','{6}', '7')",
                pEmpleado.Id, pEmpleado.Clave, pEmpleado.Direccion, pEmpleado.Telefono, pEmpleado.Nombre, pEmpleado.Apellido1,
                pEmpleado.Apellido2, pEmpleado.Puesto), Base_Datos.Conexion());

            retorno = comando.ExecuteNonQuery();
            return retorno;
        }

        public static List<Empleado> Buscar(int pID) // Esta clase sirve para buscar un empleado en la BD
        {
            List<Empleado> _lista = new List<Empleado>();

            MySqlCommand _comando = new MySqlCommand(String.Format(
           "SELECT ID, Clave, Dirección, Telefono, Nombre, Apellido1, Apellido2, Puesto" +
           " FROM empleado  where Clave ='{0}'", pID), Base_Datos.Conexion());
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read()) // Mientra haya lectura de datos va a hacer la captura de datos.
            {
                Empleado pEmpleado = new Empleado();
                pEmpleado.Id = _reader.GetInt32(0);
                pEmpleado.Clave = _reader.GetInt32(1);
                pEmpleado.Direccion = _reader.GetString(2);
                pEmpleado.Telefono = _reader.GetString(3);
                pEmpleado.Nombre = _reader.GetString(4);
                pEmpleado.Apellido1 = _reader.GetString(5);
                pEmpleado.Apellido2 = _reader.GetString(6);
                pEmpleado.Puesto = _reader.GetString(7);

                _lista.Add(pEmpleado); // Lo agrega el empleado encontrado con ese ID.
            }

            return _lista;
        }

        public static List<Empleado> BuscarEliminar(int pID) // Esta clase sirve para buscar y eliminar a un empleado en la BD
        {
            List<Empleado> _lista = new List<Empleado>();

            MySqlCommand _comando = new MySqlCommand(String.Format(
           "SELECT * FROM empleado where noCtrl = @noCtrl"), Base_Datos.Conexion());
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read()) // Mientra haya lectura de datos va a hacer la captura de datos.
            {
                Empleado pEmpleado = new Empleado();
                pEmpleado.Id = _reader.GetInt32(0);
                pEmpleado.Clave = _reader.GetInt32(1);
                pEmpleado.Direccion = _reader.GetString(2);
                pEmpleado.Telefono = _reader.GetString(3);
                pEmpleado.Nombre = _reader.GetString(4);
                pEmpleado.Apellido1 = _reader.GetString(5);
                pEmpleado.Apellido2 = _reader.GetString(6);
                pEmpleado.Puesto = _reader.GetString(7); ;

                _lista.Add(pEmpleado); // Lo agrega el empleado encontrado con ese ID.
            }

            return _lista;
        }

        public static Empleado ObtenerEmpleado(int pID) // Esta clase sirve para jalar un empleado de la BD
        {
            Empleado pEmpleado = new Empleado();
            MySqlConnection conexion = Base_Datos.Conexion();

            MySqlCommand _comando = new MySqlCommand(String.Format("SELECT ID, Clave, Dirección, Telefono, Nombre, Apellido1, Apellido2, Puesto" +
           " FROM empleado where Clave = {0}", pID), conexion);
            MySqlDataReader _reader = _comando.ExecuteReader();
            while (_reader.Read())
            {
                // Lee los datos de la BD de forma ordenada
                pEmpleado.Id = _reader.GetInt32(0);
                pEmpleado.Clave = _reader.GetInt32(1);
                pEmpleado.Direccion = _reader.GetString(2);
                pEmpleado.Telefono = _reader.GetString(3);
                pEmpleado.Nombre = _reader.GetString(4);
                pEmpleado.Apellido1 = _reader.GetString(5);
                pEmpleado.Apellido2 = _reader.GetString(6);
                pEmpleado.Puesto = _reader.GetString(7);

            }
            // Se cierra la conexion a la BD
            conexion.Close();
            return pEmpleado;
        }
        public static int Actualizar(Empleado pEmpleado) // Esta clase sirve para actualzar los datos de un empleado en la BD
        {
            int retorno = 0;
            MySqlConnection conexion = Base_Datos.Conexion();

            MySqlCommand comando = new MySqlCommand(string.Format("Update empleado set ID = '0', Dirección = '{1}', Telefono = '{2}', Nombre = '{3}', Apellido1 = '{4}', " + "Apellido1 = '{5}', Puesto = '{6}' where Clave = {7}",
                 pEmpleado.Direccion, pEmpleado.Telefono, pEmpleado.Nombre, pEmpleado.Apellido1, pEmpleado.Apellido2, pEmpleado.Puesto, pEmpleado.Clave), conexion);

            retorno = comando.ExecuteNonQuery();
            // Se cierra la conexion a la BD
            conexion.Close();

            return retorno;

        }
        public static int Eliminar(int pClave) // Esta clase sirve para eliminar a un empleado de la BD
        {
            int retorno = 0;
            MySqlConnection conexion = Base_Datos.Conexion();

            MySqlCommand comando = new MySqlCommand(string.Format("Delete From empleado where Clave = {0}", pClave), conexion);

            retorno = comando.ExecuteNonQuery();
            // Se cierra la conexion a la BD
            conexion.Close();

            return retorno;

        }
    }
}
