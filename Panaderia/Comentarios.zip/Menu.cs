﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;       // Librerias

namespace Panaderia
{
    public partial class Menu : Form
    {
        public Menu()
        {
            InitializeComponent();
        }

        private void PictureBox3_Click(object sender, EventArgs e)
        {
            // Se oculta la ventana actual
            this.Hide();    
            // Se crea un nuevo Form con su respectivo objeto
            Form EditarEmpleado = new EditarEmpleado();
            // Se muestra el Form creado
            EditarEmpleado.Show();
        }

        private void PictureBox1_Click(object sender, EventArgs e)
        {
            // Se oculta la ventana actual
            this.Hide();
            // Se crea un nuevo Form con su respectivo objeto
            Form AgregarEmpleado = new AgregarEmpleado();
            // Se muestra el Form creado
            AgregarEmpleado.Show();
        }

        private void PictureBox2_Click(object sender, EventArgs e)
        {
            // Se oculta la ventana actual
            this.Hide();
            // Se crea un nuevo Form con su respectivo objeto
            Form EliminarEmpleado = new EliminarEmpleado();
            // Se muestra el Form creado
            EliminarEmpleado.Show();
        }

        private void PictureBox4_Click(object sender, EventArgs e)
        {
            // Se oculta la ventana actual
            this.Hide();
            // Se crea un nuevo Form con su respectivo objeto
            BuscarEmpleado buscar = new BuscarEmpleado();
            // Se muestra el Form creado
            buscar.ShowDialog();
        }

        private void Menu_Load(object sender, EventArgs e)
        {

        }

        private void PictureBox5_Click(object sender, EventArgs e)
        {
            // Se oculta la ventana actual
            this.Hide();
            // Se crea un nuevo Form con su respectivo objeto
            Form Mantenimiento = new Mantenimiento();
            // Se muestra el Form creado
            Mantenimiento.Show();
        }

        private void PictureBox6_Click(object sender, EventArgs e)
        {
            // Se oculta la ventana actual
            this.Hide();
            // Se crea un nuevo Form con su respectivo objeto
            Form LoginEmpleado = new LoginEmpleado();
            // Se muestra el Form creado
            LoginEmpleado.Show();
        }
        // Estos enlaces nos dirigen o intentan dirigir a la empresa para la que estamos trabajando
        private void pictureBox8_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.facebook.com/alexander38493");
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://www.instagram.com/alex_glop/");
        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://twitter.com/Alexand55937250");
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start("https://api.whatsapp.com/send?phone=523328345470");
        }
        // Se mata la aplicacion completamente sin dar lugar a que este trabajando en segundo plano
        private void Menu_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }
    }
}